const express = require('express');
const cors = require('cors');
const axios = require('axios');
const mysql = require('mysql2');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const nodemailer = require('nodemailer');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// إعداد اتصال قاعدة البيانات
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME
});

db.connect((err) => {
  if (err) {
    console.error('❌ Error connecting to MySQL:', err.message);
    return;
  }
  console.log('✅ Connected to MySQL');
});

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: 'akinatorgames0@gmail.com',
    pass: 'amgj mmwr ecme lxrd',
  },
});
let gameSessions = {};


// دالة للتفاعل مع OpenAI API
async function askGPT(history, language, mode = "question") {
  try {
    const systemPrompt = `انت مخمن مدينه او ولايه بمسمى اخر (مثل اسرائيل او الاردن او مصر الخ...) يفكر فيها المستخدم, اطرح اساله دقيقه حتى تدقق الاحتمالات بناء على خصائص المدن.
ابدا بالسؤال عن القاره التي تقع فيها المدينه, ثم المناخ, اسائله هكذا لتضييق الاحتمالات, وايضا اساله مثل سؤال النقل وعدد السكان ومعالم مشهوره او بحر او بحيره, واللغة الاكثر شيوعاً لا تقم بتكرير السؤال 
يجم ان تكون جميع الاسأله بصيغة يجاب عليها ب نعم / لا / ربما / لا اعرف 
بعد ما تتاكد 100% من اسم المدينه اقترح اسم المدينه 
 تجنب طرح أسئلة عامة جدًا أو غير واضحة.
ركز على الأسئلة التي تساعد في تحديد المدينة بسرعة.
باللغة العبريه מדינה وليس עיר`;

    const userPrompts = {
      en: {
        question: "Based on these answers, what is the best next question to narrow down the possibilities? Avoid repeating previous questions.",
        guess: "Based on these answers, what is the most likely city the user is thinking of?"
      },
      he: {
        question: "בהתבסס על התשובות הללו, מהי השאלה הבאה הכי טובה כדי לצמצם את האפשרויות? הימנע מחזרה על שאלות קודמות.",
        guess: "בהתבסס על התשובות הללו, איזו עיר הכי סבירה שהמשתמש חושב עליה?"
      },
      ar: {
        question: "بناءً على هذه الإجابات، ما هو أفضل سؤال جديد يمكنني طرحه الآن لتضييق الاحتمالات؟ تجنب تكرار الأسئلة السابقة.",
        guess: "بناءً على هذه الإجابات، ما هي المدينة الأكثر احتمالًا التي يفكر بها المستخدم؟"
      }
    };

    if (!userPrompts[language]) {
      return "⚠️ اللغة غير مدعومة، يرجى اختيار لغة أخرى.";
    }

    const userPrompt = userPrompts[language][mode];

    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: "gpt-4-turbo",
        messages: [
          { role: "system", content: systemPrompt },
          ...history,  // تمرير السجل كاملاً ليكون لدى النموذج سياق الأسئلة السابقة
          { role: "user", content: userPrompt }
        ],
        temperature: 0.7,
      },
      {
        headers: {
          "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
          "Content-Type": "application/json"
        }
      }
    );

    const generatedText = response.data?.choices?.[0]?.message?.content?.trim();

    if (!generatedText) {
      return "⚠️ לא הצלחתי ליצור את השאלה בצורה נכונה. נסה שוב!";
    }

    // **إضافة السؤال الجديد إلى السجل لمنع التكرار**
    history.push({ role: "assistant", content: generatedText });

    return generatedText;
  } catch (error) {
    console.error("❌ خطأ في OpenAI:", error.response?.data || error.message);
    return "⚠️ אירעה שגיאה בעת התחברות ל-AI.";
  }
}


// تسجيل مستخدم جديد
app.post('/register', async (req, res) => {
  const { username, email, password } = req.body;

  const hashedPassword = await bcrypt.hash(password, 10);

  const emailQuery = 'SELECT * FROM users WHERE email = ?';
  db.query(emailQuery, [email], (err, emailResults) => {
    if (err) {
      console.error('Error checking email:', err);
      return res.status(500).send('Error checking email');
    }

    if (emailResults.length > 0) {
      return res.status(400).send('Email already exists');
    }

    const usernameQuery = 'SELECT * FROM users WHERE username = ?';
    db.query(usernameQuery, [username], (err, usernameResults) => {
      if (err) {
        console.error('Error checking username:', err);
        return res.status(500).send('Error checking username');
      }

      if (usernameResults.length > 0) {
        return res.status(400).send('Username already exists');
      }

      const insertQuery = 'INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, NOW())';
      db.query(insertQuery, [username, email, hashedPassword], (err, results) => {
        if (err) {
          console.error('User or Email Already Exist !', err);
          return res.status(500).send('User or Email Already Exist !');
        }

        res.status(201).send('User created');
      });
    });
  });
});



// تسجيل الدخول
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  const query = 'SELECT * FROM users WHERE email = ?';
  db.query(query, [email], async (err, results) => {
    if (err) {
      console.error('Error querying user:', err);
      return res.status(500).send('Error logging in');
    }

    // إذا لم يكن هناك مستخدم بالـ email
    if (results.length === 0) {
      return res.status(400).send('❌ Incorrect Email. Please check your email and try again.');
    }

    const user = results[0];

    // إذا كانت كلمة المرور غير صحيحة
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).send('❌ Incorrect password. Please check your password and try again.');
    }

    // تحديث تاريخ آخر تسجيل دخول
    const updateLoginQuery = 'UPDATE users SET lastlogin = ? WHERE id = ?';
    db.query(updateLoginQuery, [new Date(), user.id], (err) => {
      if (err) {
        console.error('Error updating last login:', err);
        return res.status(500).send('Error updating last login');
      }
    });

    // إذا كانت البيانات صحيحة، أنشئ الـ token
    const token = jwt.sign({ userId: user.id }, 'secretKey');
    res.json({ token });
  });
});



let verificationCodes = {};

// دالة إرسال رمز التحقق
async function sendVerificationCode(email, code) {
  console.log("Verification code sent:", code)
  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'Verification Code',
    text: `Your verification code is: ${code}`,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log('✅ Verification code sent successfully!');
  } catch (error) {
    console.error('❌ Error sending email:', error);
  }
}

app.post('/send-verification-code', async (req, res) => {
  const { email } = req.body;
  const code = Math.floor(100000 + Math.random() * 900000).toString();

  // تخزين الكود مؤقتًا مع الوقت
  verificationCodes[email] = {
    code: code,
    timestamp: Date.now(), // تسجيل وقت إرسال الكود
  };

  await sendVerificationCode(email, code); // تأكد أن هذه الدالة تقوم بإرسال البريد الإلكتروني
  res.status(200).json({ message: "✅ Verification code sent successfully", code: code });
});

// التحقق من الكود
app.post('/verify-code', (req, res) => {
  const { email, userCode } = req.body;

  // التحقق مما إذا كان الكود موجودًا
  const verificationData = verificationCodes[email];

  if (!verificationData) {
    return res.status(400).json({ message: "No verification code sent to this email." });
  }

  // التحقق من صلاحية الكود (مثال: الصلاحية تنتهي بعد 5 دقائق)
  const timeDifference = Date.now() - verificationData.timestamp;
  const isCodeExpired = timeDifference > 5 * 60 * 1000; // 5 دقائق

  if (isCodeExpired) {
    delete verificationCodes[email];  // حذف الكود بعد انتهائه
    return res.status(400).json({ message: "Verification code expired." });
  }

  // التحقق من صحة الكود
  if (userCode === verificationData.code) {
    return res.status(200).json({ message: "✅ Code verified successfully!" });
  } else {
    return res.status(400).json({ message: "Invalid verification code." });
  }
});






// نقطة النهاية للبروفايل
app.get('/profile', (req, res) => {
  const token = req.headers['authorization']?.split(' ')[1]; // استخراج التوكن من الهيدر
  if (!token) return res.status(403).send('No token provided');

  jwt.verify(token, 'secretKey', (err, decoded) => {
    if (err) return res.status(403).send('Invalid token');

    const userId = decoded.userId;
    const query = 'SELECT username, email, image, created_at, lastlogin FROM users WHERE id = ?';
    db.query(query, [userId], (err, results) => {
      if (err) {
        console.error('Error fetching user data:', err);
        return res.status(500).send('Error fetching user data');
      }
      if (results.length === 0) return res.status(404).send('User not found');
      res.json(results[0]); // إرسال بيانات المستخدم
    });
  });
});
app.get('/profile/:userId', (req, res) => {
  const userId = req.params.userId;

  const query = 'SELECT * FROM users WHERE id = ?';
  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('Error fetching user data:', err);
      return res.status(500).send('Error fetching user data');
    }

    if (results.length > 0) {
      const user = results[0];
      res.json(user); // إرسال بيانات المستخدم بما في ذلك الصورة
    } else {
      res.status(404).send('User not found');
    }
  });
});


app.post('/update-password', async (req, res) => {
  const { newPassword } = req.body;
  const token = req.headers.authorization.split(' ')[1];
  const decoded = jwt.verify(token, 'secretKey');
  const hashedPassword = await bcrypt.hash(newPassword, 10);

  const query = 'UPDATE users SET password = ? WHERE id = ?';
  db.query(query, [hashedPassword, decoded.userId], (err) => {
    if (err) {
      console.error('❌ Error updating password:', err);
      return res.status(500).send('Error updating password');
    }
    res.status(200).send('Password updated successfully');
  });
});


const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${file.originalname}`;
    cb(null, uniqueName);
  },
});
const upload = multer({ storage });


// مسار رفع الصورة
app.post('/upload-avatar', upload.single('image'), (req, res) => {
  const { username } = req.body;
  const imagePath = req.file.filename;

  const query = 'UPDATE users SET image = ? WHERE username = ?';
  db.query(query, [imagePath, username], (err, result) => {
    if (err) {
      console.error('❌ Failed to update image:', err);
      return res.status(500).send('Failed to upload image');
    }
    res.status(200).send('Image uploaded successfully');
  });
});






// خدمة عرض الصور عند الطلب
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.post('/clear-session', (req, res) => {
  gameSessions = {}; // حذف جميع الجلسات عند إعادة تحميل الصفحة
  res.status(200).send("Sessions cleared");
});

// بدء اللعبة
app.post('/start', async (req, res) => {
  const { language } = req.body;
  const sessionId = Math.random().toString(36).substring(7);

  // إنشاء جلسة جديدة دون تخزينها في قاعدة البيانات
  gameSessions[sessionId] = { history: [], questionsAsked: 0, language };

  const firstQuestion = await askGPT(gameSessions[sessionId].history, language);
  res.json({ sessionId, question: firstQuestion });
});

// استقبال الإجابة وإرسال السؤال التالي
app.post('/answer', async (req, res) => {
  console.log("📥 استقبال طلب الإجابة:", req.body);

  const { sessionId, answer } = req.body;
  if (!sessionId || !gameSessions[sessionId]) {
    console.warn("⚠️ الجلسة غير موجودة.");
    return res.status(400).json({ error: "الجلسة غير موجودة." });
  }

  const session = gameSessions[sessionId];
  session.history.push({ role: "user", content: answer });
  session.questionsAsked++;

  if (session.questionsAsked >= 15) {
    console.log("🎯 تجاوز عدد الأسئلة 15. سيتم توليد تخمين...");
    const guess = await askGPT(session.history, session.language, "guess");

    delete gameSessions[sessionId];
    console.log("✅ التخمين النهائي:", guess);
    return res.json({ question: `أعتقد أنك تفكر في: ${guess}`, isGameEnded: true });
  }

  console.log("🔄 توليد السؤال التالي...");
  const nextQuestion = await askGPT(session.history, session.language, "question");

  if (!nextQuestion) {
    console.error("❌ لم يتم استرجاع سؤال جديد! إرسال رسالة افتراضية...");
    return res.json({ question: "⚠️ لم أتمكن من توليد سؤال جديد. حاول مرة أخرى." });
  }

  console.log("✅ السؤال التالي:", nextQuestion);
  res.json({ question: nextQuestion });
});


// تشغيل السيرفر
app.listen(PORT, () => console.log(`✅ Server running on http://localhost:${PORT}`));
