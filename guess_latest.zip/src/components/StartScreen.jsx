import React from 'react';
import { useTranslation } from 'react-i18next'

const StartScreen = ({ startGame }) => {
  const { t } = useTranslation();

  return (
    <div className="start-screen flex items-center justify-center text-white bg-gradient-to-t via-grey-900 to-purple-900 ">
      <button
        onClick={() => startGame()}
        className="bg-gradient-to-t text-xl font-semibold py-4 px-8 rounded-lg shadow-2xl hover:shadow-lg transform  transition-transform duration-300 ease-in-out"
      >
        {t('start_game')}
      </button>
      
    </div>
  );
};

export default StartScreen;
