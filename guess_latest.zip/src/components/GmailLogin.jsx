import React from 'react';
import { GoogleLogin } from 'react-google-login';
import { useNavigate } from 'react-router-dom';

const GmailLogin = () => {
  const navigate = useNavigate();

  const responseGoogle = (response) => {
    console.log('Google response:', response);

    if (response.profileObj) {
      console.log('Name:', response.profileObj.name);
      console.log('Email:', response.profileObj.email);

      // حفظ البيانات في localStorage أو حالة التطبيق
      localStorage.setItem('user', JSON.stringify(response.profileObj));

      // ✅ إعادة توجيه المستخدم إلى الصفحة الرئيسية
      navigate('/dashboard'); // قم بتغيير الوجهة حسب احتياجك
    }

    if (response.tokenId) {
      console.log('ID Token:', response.tokenId);
    }
  };

  return (
    <div className="App">
      <h2>Sign in with Google</h2>

      <GoogleLogin
        clientId="1093825253975-f3564j0g7epjr8fav55igjjb4mf2a68u.apps.googleusercontent.com"
        buttonText="Login with Google"
        onSuccess={responseGoogle}
        onFailure={responseGoogle}
        cookiePolicy={'single_host_origin'}
      />
    </div>
  );
};

export default GmailLogin;
