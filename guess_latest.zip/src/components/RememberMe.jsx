import { useState, useEffect } from "react";

const RememberMe = () => {
  const [remember, setRemember] = useState(false);

  useEffect(() => {
    const savedPreference = localStorage.getItem("rememberMe");
    if (savedPreference) {
      setRemember(JSON.parse(savedPreference));
    }
  }, []);

  const handleChange = (event) => {
    const isChecked = event.target.checked;
    setRemember(isChecked);
    localStorage.setItem("rememberMe", JSON.stringify(isChecked));
  };

  return (
    <div>
      <label>
        <input className="mx-1 mt-3" type="checkbox" checked={remember} onChange={handleChange} />
        Remember Me
      </label>
    </div>
  );
};

export default RememberMe;