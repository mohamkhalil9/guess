import React, { useState, useEffect } from 'react';

const CountdownTimer = () => {
  // تهيئة حالة العد التنازلي مع 5 دقائق (300 ثانية)
  const [time, setTime] = useState(300);

  useEffect(() => {
    // إذا وصل العداد إلى 0، توقف عن العد التنازلي
    if (time === 0) return;

    // تعيين فترة لتقليل الوقت كل ثانية
    const interval = setInterval(() => {
      setTime((prevTime) => prevTime - 1);
    }, 1000);

    // تنظيف الفترة عند فك تجميع المكون أو وصول الوقت إلى 0
    return () => clearInterval(interval);
  }, [time]);

  // تنسيق الوقت إلى دقائق وثواني
  const minutes = Math.floor(time / 60);
  const seconds = time % 60;

  return (
    <div>
      <p>
        Code expire in: <br></br>
        {String(minutes).padStart(2, '0')}:
        {String(seconds).padStart(2, '0')}
      </p>
    </div>
  );
};

export default CountdownTimer;
