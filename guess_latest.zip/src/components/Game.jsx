import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

const Game = ({ question, submitAnswer }) => {
  const { t } = useTranslation();
  const [displayedQuestion, setDisplayedQuestion] = useState('');
  const [isQuestionComplete, setIsQuestionComplete] = useState(false);
  const [isThinking, setIsThinking] = useState(false);  // حالة التفكير بين الأسئلة
  const [thinkingMessage, setThinkingMessage] = useState(''); // لحفظ الرسالة المؤقتة

  const thinkingMessages = [
    t('wait1'),
    t('wait2'),
    t('wait3'),
    t('wait4')
  ];

  useEffect(() => {
    if (question && question.trim() !== '') {
      setIsThinking(true); // بدأنا التفكير بين الأسئلة
      const randomMessage = thinkingMessages[Math.floor(Math.random() * thinkingMessages.length)];
      setThinkingMessage(randomMessage); // اختيار رسالة عشوائية
      setDisplayedQuestion(randomMessage); // عرض النص المؤقت أثناء التفكير
      setIsQuestionComplete(false); // إخفاء الأزرار مؤقتًا
      // تأخير بسيط لمحاكاة التفكير
      setTimeout(() => {
        setDisplayedQuestion(question); // عرض السؤال الجديد
        setIsThinking(false); // التوقف عن التفكير بعد عرض السؤال
        setIsQuestionComplete(true); // إظهار الأزرار بعد عرض السؤال
      }, 1500); // تأخير 1.5 ثانية قبل عرض السؤال الجديد
    } else {
      setDisplayedQuestion("انتظر قليلاً..."); // رسالة مؤقتة إذا كان السؤال فارغًا
      setIsQuestionComplete(false); // التأكد من أن الأزرار لا تظهر
    }
  }, [question]); // التأكد من أن السؤال يتغير فقط عند تغييره

  const handleAnswer = (answer) => {
    submitAnswer(answer); // إرسال الإجابة
    setIsQuestionComplete(false); // إخفاء الأزرار بعد الإجابة
  };

  return (
    <div className="game-container text-center">
      {/* عرض السؤال أو النص المؤقت أثناء التفكير */}
      <p className={`question mb-8 font-bold text-white whitespace-normal break-words transition-all duration-700 ease-in-out transform opacity-0 ${isQuestionComplete || isThinking ? 'opacity-100' : 'opacity-0'}`}>
        {displayedQuestion || "Loading..."}
      </p>

      {/* إظهار الأزرار فقط بعد اكتمال السؤال */}
      {isQuestionComplete && !isThinking && (
        <div className="answer-buttons space-y-4">
<button 
  onClick={() => handleAnswer(t('correct'))} 
  className="w-full py-4 rounded-lg text-lg bg-gradient-to-r from-indigo-500 to-purple-600 
  hover:from-indigo-700 hover:to-purple-800 text-green-500"
>
  {t('correct')}
</button>

          <button 
            onClick={() => handleAnswer(t('incorrect'))} 
            className="w-full py-4 rounded-lg text-lg bg-gradient-to-r from-indigo-500 to-purple-600 
  hover:from-indigo-700 hover:to-purple-800 text-red-500">
            {t('incorrect')}
          </button>
          <button 
            onClick={() => handleAnswer(t('maybe'))} 
            className="w-full py-4 rounded-lg text-lg bg-gradient-to-r from-indigo-500 to-purple-600 
  hover:from-indigo-700 hover:to-purple-800 text-orange-500">
            {t('maybe')}
          </button>
          <button 
            onClick={() => handleAnswer(t('idk'))} 
            className="w-full py-4 rounded-lg text-lg bg-gradient-to-r from-indigo-500 to-purple-600 
  hover:from-indigo-700 hover:to-purple-800 text-yellow-500">
            {t('idk')}
          </button>
        </div>
      )}
      
    </div>

    
  );
};

export default Game;
