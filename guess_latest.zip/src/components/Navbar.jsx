import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const Navbar = ({ changeLanguage }) => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState(null);
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const handleLanguageChange = (language) => {
    i18n.changeLanguage(language);
    changeLanguage(language);
    setIsDropdownOpen(false);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setIsLoggedIn(false);
    setUser(null);
    window.location.reload();
    navigate('/');
  };

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      axios
        .get('http://localhost:3001/profile', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        })
        .then((response) => {
          setUser(response.data.user);
          setIsLoggedIn(true);
        })
        .catch(() => {
          setIsLoggedIn(false);
        });
    } else {
      setIsLoggedIn(false);
    }
  }, []);

  return (
    <header className="bg-purple-900 bg-gradient-to-l from-gray-900 via-gray-900 to-purple-800 w-full p-4 shadow-2xl">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <Link to={"/game"}>
          <div className="text-xl font-bold text-white">{t('game_name')}</div>
        </Link>
        <nav className="space-x-5 flex items-center shadow-lg">
          <Link to={"/game"}>
          <button className="group flex items-center gap-2 text-white 
                   bg-gradient-to-r from-indigo-500 to-purple-600 
                   hover:from-indigo-700 hover:to-purple-800 
                   border border-white/30 shadow-xl 
                   px-6 py-2 rounded-xl 
                   transition-all duration-500 ease-in-out 
                   hover:scale-105 active:scale-95">
  <svg 
    className="fill-current transform transition-transform duration-500 group-hover:-translate-y-1" 
    xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <path d="M21 13v10h-6v-6h-6v6h-6v-10h-3l12-12 12 12h-3zm-1-5.907v-5.093h-3v2.093l3 3z"/>
  </svg>
  {t('home')}
</button>

          </Link>

          {isLoggedIn && (
            <div className="flex items-center space-x-4">
              <Link to={"/profile"}>
              <button 
  className="flex items-center justify-center gap-2 
             text-white 
             bg-gradient-to-r from-indigo-500 to-purple-600 
             hover:from-indigo-700 hover:to-purple-800 
             active:scale-95 
             border border-white/30 
             shadow-xl 
             px-6 py-2 
             rounded-xl 
             transition-all duration-300 ease-in-out 
             hover:scale-105"
>
<svg className='fill-current' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M19 7.001c0 3.865-3.134 7-7 7s-7-3.135-7-7c0-3.867 3.134-7.001 7-7.001s7 3.134 7 7.001zm-1.598 7.18c-1.506 1.137-3.374 1.82-5.402 1.82-2.03 0-3.899-.685-5.407-1.822-4.072 1.793-6.593 7.376-6.593 9.821h24c0-2.423-2.6-8.006-6.598-9.819z"/></svg>

  {t('profile')}
</button>


              </Link>
              <Link to={"/login"}>
              <button
  onClick={handleLogout}
  className="group flex items-center gap-2 text-white 
             bg-gradient-to-r from-indigo-500 to-purple-600 
             hover:from-indigo-900 hover:to-purple-900 
             border border-white/30 shadow-xl 
             px-6 py-2 rounded-xl 
             transition-all duration-300 
             hover:scale-105 active:scale-95"
>
  <svg
    className="w-5 h-5 fill-current transition-transform duration-300 group-hover:-translate-y-1"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 1080 1080"
  >
    <path d="M917.7 148.8l-42.4-42.4c-1.6-1.6-3.6-2.3-5.7-2.3s-4.1.8-5.7 2.3l-76.1 76.1a199.27 199.27 0 0 0-112.1-34.3c-51.2 0-102.4 19.5-141.5 58.6L432.3 308.7a8.03 8.03 0 0 0 0 11.3L704 591.7c1.6 1.6 3.6 2.3 5.7 2.3 2 0 4.1-.8 5.7-2.3l101.9-101.9c68.9-69 77-175.7 24.3-253.5l76.1-76.1c3.1-3.2 3.1-8.3 0-11.4zM769.1 441.7l-59.4 59.4-186.8-186.8 59.4-59.4c24.9-24.9 58.1-38.7 93.4-38.7 35.3 0 68.4 13.7 93.4 38.7 24.9 24.9 38.7 58.1 38.7 93.4 0 35.3-13.8 68.4-38.7 93.4zm-190.2 105a8.03 8.03 0 0 0-11.3 0L501 613.3 410.7 523l66.7-66.7c3.1-3.1 3.1-8.2 0-11.3L441 408.6a8.03 8.03 0 0 0-11.3 0L363 475.3l-43-43a7.85 7.85 0 0 0-5.7-2.3c-2 0-4.1.8-5.7 2.3L206.8 534.2c-68.9 69-77 175.7-24.3 253.5l-76.1 76.1a8.03 8.03 0 0 0 0 11.3l42.4 42.4c1.6 1.6 3.6 2.3 5.7 2.3s4.1-.8 5.7-2.3l76.1-76.1c33.7 22.9 72.9 34.3 112.1 34.3 51.2 0 102.4-19.5 141.5-58.6l101.9-101.9c3.1-3.1 3.1-8.2 0-11.3l-43-43 66.7-66.7c3.1-3.1 3.1-8.2 0-11.3l-36.6-36.2zM441.7 769.1a131.32 131.32 0 0 1-93.4 38.7c-35.3 0-68.4-13.7-93.4-38.7a131.32 131.32 0 0 1-38.7-93.4c0-35.3 13.7-68.4 38.7-93.4l59.4-59.4 186.8 186.8-59.4 59.4z"/>
  </svg>
  {t('logout')}
</button>

              </Link>
            </div>
          )}

          <div className="relative">
            <button
              onClick={toggleDropdown}
              className="flex items-center justify-center gap-2 
             text-white 
             bg-gradient-to-r from-indigo-500 to-purple-600 
             hover:from-indigo-700 hover:to-purple-800 
             active:scale-95 
             border border-white/30 
             shadow-xl 
             px-6 py-2 
             rounded-xl 
             transition-all duration-300 ease-in-out 
             hover:scale-105">
              <svg className='fill-current' xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M24 24h-2.784l-1.07-3h-4.875l-1.077 3h-2.697l4.941-13h2.604l4.958 13zm-4.573-5.069l-1.705-4.903-1.712 4.903h3.417zm-9.252-12.804c.126-.486.201-.852.271-1.212l-2.199-.428c-.036.185-.102.533-.22 1-.742-.109-1.532-.122-2.332-.041.019-.537.052-1.063.098-1.569h2.456v-2.083h-2.161c.106-.531.198-.849.288-1.149l-2.147-.645c-.158.526-.29 1.042-.422 1.794h-2.451v2.083h2.184c-.058.673-.093 1.371-.103 2.077-2.413.886-3.437 2.575-3.437 4.107 0 1.809 1.427 3.399 3.684 3.194 2.802-.255 4.673-2.371 5.77-4.974 1.134.654 1.608 1.753 1.181 2.771-.396.941-1.561 1.838-3.785 1.792v2.242c2.469.038 4.898-.899 5.85-3.166.93-2.214-.132-4.635-2.525-5.793zm-2.892 1.531c-.349.774-.809 1.544-1.395 2.15-.09-.646-.151-1.353-.184-2.108.533-.07 1.072-.083 1.579-.042zm-3.788.724c.062.947.169 1.818.317 2.596-1.996.365-2.076-1.603-.317-2.596zm11.236-1.745l-2.075-5.533 5.414-1.104-.976 1.868c2.999 2.418 4.116 5.645 4.532 8.132-1.736-2.913-3.826-4.478-5.885-5.321l-1.01 1.958zm-7.895 10.781l1.985 5.566-5.43 1.016 1.006-1.852c-2.96-2.465-4.021-5.654-4.397-8.148 1.689 2.94 3.749 4.483 5.794 5.36l1.042-1.942zm10.795-6.029"/></svg>
              {t('languages')}
            </button>
            {isDropdownOpen && (
              <div className="absolute right-0 mt-2 bg-transparent text-white rounded-lg shadow-lg w-40">
                <ul>
                  <li
                    onClick={() => handleLanguageChange('he')}
                    className={`flex flex-col items-center justify-center px-4 py-2 hover:bg-indigo-900 cursor-pointer ${i18n.language === 'he' ? 'bg-gradient-to-b from-gray-900 via-gray-900 to-purple-800' : ''}`}
                  >
                    עברית
                    <img
                      src="https://upload.wikimedia.org/wikipedia/commons/d/d4/Flag_of_Israel.svg"
                      alt="Israel"
                      className="w-7 h-6 mb-2"
                    />
                  </li>
                  <li
                    onClick={() => handleLanguageChange('ar')}
                    className={`flex flex-col items-center justify-center px-4 py-2 hover:bg-indigo-900 cursor-pointer border-t border-gray-500 ${i18n.language === 'ar' ? 'bg-gradient-to-b from-gray-900 via-gray-900 to-purple-800' : ''}`}
                  >
                    العربية
                    <img
                      src="https://upload.wikimedia.org/wikipedia/commons/0/0d/Flag_of_Saudi_Arabia.svg"
                      alt="Saudi Arabia"
                      className="w-6 h-6 mb-2"
                    />
                  </li>
                  <li
                    onClick={() => handleLanguageChange('en')}
                    className={`flex flex-col items-center justify-center px-4 py-2 hover:bg-indigo-900 cursor-pointer border-t border-gray-500 ${i18n.language === 'en' ? 'bg-gradient-to-b from-gray-900 via-gray-900 to-purple-800' : ''}`}
                  >
                    English
                    <img
                      src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Flag_of_the_United_States.svg"
                      alt="USA"
                      className="w-6 h-6 mb-2"
                    />
                  </li>
                </ul>
              </div>
            )}
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Navbar;