import { useState, useEffect, useRef } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import CountdownTimer from "./CountDown";

const VerifyCode = () => {
  const [userCodeArray, setUserCodeArray] = useState(["", "", "", "", "", ""]);
  const [isCodeSent, setIsCodeSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [storedCode, setStoredCode] = useState("");
  const [resetTimer, setResetTimer] = useState(false);
  const [canResend, setCanResend] = useState(true);
  const [resendTimer, setResendTimer] = useState(60);
  const navigate = useNavigate();

  const inputRefs = useRef([]);

  useEffect(() => {
    let timer;
    if (!canResend) {
      timer = setInterval(() => {
        setResendTimer((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setCanResend(true);
            return 60;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [canResend]);

  const sendCode = async () => {
    if (!canResend) return;
    const email = localStorage.getItem("email");
    if (!email) {
      setErrorMessage("Please log in first.");
      return;
    }
    try {
      setLoading(true);
      const response = await axios.post("http://localhost:3001/send-verification-code", { email });
      const code = response.data.code;
      setStoredCode(code);
      setIsCodeSent(true);
      setSuccessMessage("Verification code sent!");
      setErrorMessage("");
      setResetTimer(true);
      setCanResend(false);
      setResendTimer(60);
    } catch (error) {
      setErrorMessage("Failed to send verification code.");
      setSuccessMessage("");
      console.error(error);
    } finally {
      setLoading(false);
      setTimeout(() => setResetTimer(false), 100);
    }
  };

  const verifyCode = () => {
    const userCode = userCodeArray.join("");
    if (!userCode.trim()) {
      setErrorMessage("Please enter the verification code.");
      return;
    }
    if (userCode.trim() === storedCode.trim()) {
      localStorage.setItem("isVerified", "true");
      setSuccessMessage("Verified successfully! You can now enter the game.");
      setErrorMessage("");
      window.location.href = "/game";
    } else {
      localStorage.setItem("isVerified", "false");
      setErrorMessage("Invalid code. Try again.");
      setSuccessMessage("");
    }
  };

  return (
    <>
      <div className="bg-purple-900 absolute top-0 left-0 bg-gradient-to-b from-gray-900 via-gray-900 to-purple-800 bottom-0 leading-5 h-full w-full overflow-hidden"></div>
      <div className="relative sm:flex sm:flex-row justify-center bg-transparent rounded-3xl shadow-2xl py-10 px-10">
        <div className="flex-col flex self-center lg:px-14 sm:max-w-4xl xl:max-w-md z-10">
          <div className="w-full max-w-md self-start hidden lg:flex flex-col text-gray-300">
            <h1 className="text-white text-3xl sm:text-4xl font-semibold text-center mb-6">
              <span className="text-white mr-2 flex items-center justify-center">Trust But</span>
              <span>Verify</span>
            </h1>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              verifyCode();
            }}
          >
            {isCodeSent && (
              <div className="mb-6">
                <label htmlFor="Code" className="block text-gray-300">
                  Enter the Code
                </label>
                <div className="flex gap-2 mt-2">
                  {userCodeArray.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => (inputRefs.current[index] = el)}
                      type="text"
                      maxLength="1"
                      value={digit}
                      onChange={(e) => {
                        const newCodeArray = [...userCodeArray];
                        const value = e.target.value.replace(/[^0-9]/g, "");
                        newCodeArray[index] = value;
                        setUserCodeArray(newCodeArray);
                        if (value && index < userCodeArray.length - 1) {
                          inputRefs.current[index + 1]?.focus();
                        }
                      }}
                      onKeyDown={(e) => {
                        if (e.key === "Backspace" && !userCodeArray[index]) {
                          if (index > 0) {
                            inputRefs.current[index - 1]?.focus();
                          }
                        }
                      }}
                      className="w-12 h-16 text-center text-2xl border-2 border-blue-500 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-black text-white transition-transform duration-300 hover:scale-110"
                    />
                  ))}
                </div>
              </div>
            )}

            {errorMessage && <div className="text-red-500 text-sm mb-4">{errorMessage}</div>}
            {successMessage && <div className="text-green-500 text-sm mb-4">{successMessage}</div>}

            {isCodeSent && (
              <div className="text-white-500 text-sm mb-4">
                <button
                  className="w-75 py-1 px-2 bg-purple-600 text-white rounded hover:bg-purple-500 transition duration-300 mt-4"
                  onClick={sendCode}
                  disabled={!canResend || loading}
                >
                  {canResend ? "Resend Code" : `Wait ${resendTimer}s`}
                </button>
              </div>
            )}

            {isCodeSent && <CountdownTimer key={resetTimer} />}

            {!isCodeSent ? (
              <button
                type="button"
                onClick={sendCode}
                className="w-full py-2 bg-purple-600 text-white rounded hover:bg-purple-500 transition duration-300"
                disabled={loading}
              >
                {loading ? "Sending..." : "Send Code"}
              </button>
            ) : (
              <button
                type="submit"
                className="w-full py-2 bg-purple-600 text-white rounded hover:bg-purple-500 transition duration-300 mt-4"
                disabled={loading || userCodeArray.includes("")}
              >
                Verify
              </button>
            )}
          </form>
        </div>
      </div>
    </>
  );
};

export default VerifyCode;
