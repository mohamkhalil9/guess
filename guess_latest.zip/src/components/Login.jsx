import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, Link, Navigate, Routes } from 'react-router-dom';
import RememberMe from './RememberMe';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [errorMessage, setErrorMessage] = useState(''); // حالة رسالة الخطأ
  const [loading, setLoading] = useState(false); // حالة التحميل
  const navigate = useNavigate();

  // تحقق من حالة التوكن عند تحميل الصفحة أو بعد تغيير حالته
  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);  // تعيين الحالة بناءً على وجود التوكن
  }, []); // التأثير يعمل مرة واحدة فقط عند تحميل الصفحة

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    // تحقق من صحة المدخلات قبل إرسال الطلب
    if (!email) {
      setErrorMessage("يرجى إدخال البريد الإلكتروني.");
      return;
    }
    if (!password) {
      setErrorMessage("يرجى إدخال كلمة المرور.");
      return;
    }
    if (password.length < 8 || password.length > 16) {
      alert('يجب أن تكون كلمة المرور 8 أحرف على الأقل');
      return;
  }
    
    setErrorMessage(""); // مسح رسالة الخطأ السابقة
    setLoading(true); // تفعيل حالة التحميل
  
    try {
      const response = await axios.post('http://localhost:3001/login', { email, password });
      const token = response.data.token;
      localStorage.setItem('token', token); // تخزين التوكن في localStorage
      localStorage.setItem('email', email); // تخزين البريد الإلكتروني في localStorage
      setIsLoggedIn(true); // تحديث حالة المستخدم بعد تسجيل الدخول بنجاح
      setLoading(false); // إيقاف حالة التحميل
      navigate('/verify-code', { replace: true }); // توجيه المستخدم إلى صفحة التحقق
    } catch (error) {
      setLoading(false); // إيقاف حالة التحميل عند حدوث خطأ
      setErrorMessage("حدث خطأ أثناء تسجيل الدخول. يرجى المحاولة مرة أخرى."); // إظهار رسالة الخطأ
      console.error("Error during login:", error);
    }
  };
  

  const handleLogout = () => {
    localStorage.removeItem('token'); // إزالة التوكن عند تسجيل الخروج
    setIsLoggedIn(false); // تحديث الحالة إلى غير مسجل الدخول
    navigate('/login', { replace: true }); // العودة إلى صفحة تسجيل الدخول مع منع التكرار
  };

  return (
    <>
      <div className="bg-purple-900 absolute top-0 left-0 bg-gradient-to-b from-gray-900 via-gray-900 to-purple-800 bottom-0 leading-5 h-full w-full overflow-hidden"></div>
      <div className="relative sm:flex sm:flex-row justify-center bg-transparent rounded-3xl shadow-2xl py-10 px-10">
        <div className="flex-col flex self-center lg:px-14 sm:max-w-4xl xl:max-w-md z-10">
          <div className="self-start hidden lg:flex flex-col text-gray-300">
            <h1 className="my-3 font-semibold text-4xl">Welcome back</h1>
          </div>
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label htmlFor="email" className="block text-gray-300">Email</label>
              <input
                type="email"
                id="email"
                name="email"
                className="w-full px-4 py-2 mt-2 bg-gray-700 text-white rounded"
                value={email} // ربط المدخل مع حالة email
                onChange={(e) => setEmail(e.target.value)} // تحديث حالة email عند الكتابة
                required
              />
            </div>
            <div className="mb-6">
              <label htmlFor="password" className="block text-gray-300">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                className="w-full px-4 py-2 mt-2 bg-gray-700 text-white rounded"
                value={password} // ربط المدخل مع حالة password
                onChange={(e) => setPassword(e.target.value)} // تحديث حالة password عند الكتابة
                required
              />
              <RememberMe/>
            </div>
            {errorMessage && <div className="text-red-500 text-sm mb-4">{errorMessage}</div>}
            <button
              type="submit"
              className="w-full py-2 bg-purple-600 text-white rounded hover:bg-purple-500 transition duration-300"
              disabled={loading} // تعطيل الزر عند تحميل البيانات
            >
              {loading ? 'Logging in...' : 'Log In'}
            </button>
            <p className="text-center mt-4 text-gray-300 drop-shadow-md">Don't have an account?</p>
              <Link to="/register" className="text-purple-600 hover:text-purple-400 drop-shadow-md">Register Here</Link>
              
          </form>
        </div>
      </div>
    </>
  );
};

export default Login;
