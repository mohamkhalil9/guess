import React from 'react';
import { useTranslation } from 'react-i18next';

const DownloadPage = () => {
  const { t } = useTranslation();

  return (
<h1 className="bg-gradient-to-b from-gray-900 via-gray-800 to-purple-900 text-white py-8 w-full flex flex-col items-center justify-center px-4 text-5xl">
  {t('Soon')}
</h1>

  );
};

export default DownloadPage;
