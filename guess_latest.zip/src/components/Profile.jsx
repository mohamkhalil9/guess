import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useTranslation } from 'react-i18next';

const Profile = () => {
  const { t } = useTranslation();
  const [userData, setUserData] = useState(null);
  const [newPassword, setNewPassword] = useState('');
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingProfile, setLoadingProfile] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserData = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        navigate('/login');
        return;
      }

      try {
        const response = await axios.get('http://localhost:3001/profile', {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUserData(response.data);
        setImagePreview(response.data.image || '');

        setTimeout(() => {
          setLoadingProfile(false);
        }, 2000);
      } catch (error) {
        console.error('Error fetching user data:', error);
        navigate('/login');
      }
    };

    fetchUserData();
  }, [navigate]);

  const handlePasswordChange = async () => {
    if (newPassword.length < 8 || newPassword.length > 16) {
      alert('סיסמה חייבת 8 תווים לפחות');
      return;
    }

    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:3001/update-password',
        { newPassword },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      alert('סיסמה עודכנה בהצלחה');
      setNewPassword('');
    } catch (error) {
      console.error('Error updating password:', error);
      alert('שגיאה בעדכון הסיסמה');
    }
    setLoading(false);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append('image', file);
      formData.append('username', userData.username);

      axios.post('/upload-avatar', formData)
        .then(response => {
          alert('Image updated successfully!');
          setImagePreview(URL.createObjectURL(file));
        })
        .catch(error => {
          console.error('Error uploading image:', error);
        });
    }
  };

  // const handleImageSave = async () => {
  //   if (!image) {
  //     alert('يرجى اختيار صورة أولاً');
  //     return;
  //   }
  
  //   setLoading(true);
  //   try {
  //     const token = localStorage.getItem('token');
  //     const formData = new FormData();
  //     formData.append('image', image);
  //     formData.append('username', userData.username);
  
  //     const response = await axios.post('http://localhost:3001/upload-avatar', formData, {
  //       headers: {
  //         Authorization: `Bearer ${token}`,
  //         'Content-Type': 'multipart/form-data',
  //       },
  //     });
  
  //     // ✅ تحديث العرض المسبق للصورة
  //     setImagePreview(URL.createObjectURL(image));
  
  //     alert('تم تحديث الصورة بنجاح!');
  //   } catch (error) {
  //     console.error('Error uploading image:', error);
  //     alert('فشل رفع الصورة');
  //   }
  //   setLoading(false);
  // };
  

  if (loadingProfile) {
    return <div className="text-center text-white-500 text-5xl">{t('loading')}</div>;
  }

  if (!userData) return <div className="text-center text-white-500 text-5xl">{t('loading')}</div>;

  return (
    
    <div className="flex justify-center items-center from-indigo-500 via-purple-500 to-pink-500 ">
      <div className="bg-purple-900 bg-gradient-to-b from-gray-900 via-gray-900 to-purple-800  top-10 rounded-2xl shadow-2xl w-full max-w-lg text-center  ">
        <div className="relative">
        <h2 className="text-3xl font-bold text-indigo-200 mt-6 underline">{t("profile")}</h2>

          <img
            src={'https://play-lh.googleusercontent.com/rjX8LZCV-MaY3o927R59GkEwDOIRLGCXFphaOTeFFzNiYY6SQ4a-B_5t7eUPlGANrcw'}
            alt="User"
            className="w-32 h-32 rounded-full border-4 border-purple-600 object-cover mx-auto transition-transform duration-300 hover:scale-105"
          />
        </div>

        <p className="text-white mt-2">{userData.username} <strong className='text-gray-400 bold underline'>:{t("username")}</strong> </p>
        <p className="text-white">{userData.email} <strong className='text-gray-400 bold underline'>:{t("email")}</strong></p>

        <div className="mt-6">
          <label htmlFor="newPassword" className="text-gray-100 font-bold underline">{t("newPassword")}</label>
          <br />
          <input
            id="newPassword"
            type="password"
            placeholder={t("wNewPassword")}
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="mt-3 p-4 bg-transparent text-purple-500 placeholder-gray-300 border-2 border-purple-500 rounded-lg focus:ring-4 focus:ring-purple-400 focus:outline-none transition-all duration-300 text-center"
            />
        </div>
        <button
          onClick={handlePasswordChange}
          className="mt-3 px-10 py-3 bg-gray-900 text-white rounded-lg border-2 border-indigo-500 hover:bg-indigo-700 transition duration-300"
          disabled={loading}
        >
          {loading ? `${t("updating")}...` : `${t("updatePassword")}`}
        </button>
      </div>
    </div>
  );
};

export default Profile;