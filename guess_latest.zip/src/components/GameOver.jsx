const GameOver = ({ question, startGame }) => {
    return (
      <div className="game-over text-center">
        <p className="text-xl mb-6">{question}</p>
        <button onClick={startGame} className="py-4 bg-blue-600 text-white rounded-lg w-full hover:bg-blue-700">
          إعادة تشغيل اللعبة
        </button>
      </div>
    );
  };
  
  export default GameOver;
  