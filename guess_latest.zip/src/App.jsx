import React, { useState, useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import axios from 'axios';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Register from './components/Register';
import Login from './components/Login';
import VerifyCode from './components/verifyCode';
import Profile from './components/Profile';
import Game from './components/Game';
import StartScreen from './components/StartScreen';
import GameOver from './components/GameOver';
import DownloadPage from './components/download';
import './components/i18n';

const App = () => {
  const [sessionId, setSessionId] = useState(null);
  const [language, setLanguage] = useState('he'); // اللغة الافتراضية
  const [question, setQuestion] = useState('');
  const [isGameEnded, setIsGameEnded] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [loading, setLoading] = useState(true); // حالة التحميل

  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isVerified, setIsVerified] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const verifiedStatus = localStorage.getItem("isVerified");

    setIsLoggedIn(!!token);
    setIsVerified(verifiedStatus === "true");

    setLoading(false); // انتهى التحميل
  }, []);

  const sendRequest = async (url, data) => {
    try {
      const response = await axios.post(url, data);
      return response.data;
    } catch (error) {
      console.error('Error in API request:', error);
    }
  };

  const startGame = async (language) => {
    if (gameStarted) return;
    const data = { language };
    const response = await sendRequest('http://localhost:3001/start', data);

    if (response) {
      setSessionId(response.sessionId);
      setQuestion(response.question);
      setGameStarted(true);
      setIsGameEnded(false);
    }
  };

  const submitAnswer = async (answer) => {
    const data = { sessionId, answer };
    const response = await sendRequest('http://localhost:3001/answer', data);

    if (response) {
      setQuestion(response.question);

      if (response.isGameEnded) {
        setIsGameEnded(true);
        setGameStarted(false);
      }
    }
  };

  const changeLanguage = (newLanguage) => {
    if (gameStarted) return;
    setLanguage(newLanguage);
  };

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center text-white text-2xl">
        טעינה...
      </div>
    );
  }
  window.onbeforeunload = function () {
    fetch('/clear-session', { method: 'POST' }); // حذف الجلسة عند إغلاق الصفحة
  };
  
  return (
    <div className="h-full w-full bg-purple-900 bg-gradient-to-b from-gray-900 via-gray-900 to-purple-800 text-white flex flex-col items-center justify-center absolute top-0 left-0">
      <Navbar changeLanguage={changeLanguage} />
      <main className="flex-grow flex items-center justify-center p-4 w-full ">
        <div className=" rounded-xl max-w-md w-full shadow-lg bg-slate-950 from-gray-900 to-purple-900 border-4 border-purple-800">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />
            <Route path="/verify-code" element={<VerifyCode />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/download" element={<DownloadPage />} />
            <Route
              path="/game"
              element={isLoggedIn && isVerified ? (
                gameStarted && !isGameEnded ? (
                  <Game question={question} submitAnswer={submitAnswer} />
                ) : isGameEnded ? (
                  <GameOver question={question} startGame={startGame} />
                ) : (
                  <StartScreen startGame={() => startGame(language)} />
                )
              ) : (
                <Navigate to="/login" replace />
              )}
            />
            <Route
              path="/"
              element={
              <Navigate to="/login" replace />
              }
            />
          </Routes>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default App;